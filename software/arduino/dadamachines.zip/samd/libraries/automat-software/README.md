# automat-software
the software for the automat
